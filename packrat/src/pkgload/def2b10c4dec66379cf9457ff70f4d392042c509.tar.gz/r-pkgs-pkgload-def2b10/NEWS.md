# pkgload 0.0.0.9000

* `dev_help()` now optionally takes a character vector of packages to
  search within.  This replaces `find_topic()`.
  
* `dev_topic_index_reset()` is now exported, and allows you to reset
  the topic index associated with a given package.

* Added a `NEWS.md` file to track changes to the package.



