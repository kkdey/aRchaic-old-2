`ordiArgAbsorber` <- function(..., shrink, origin, scaling, triangular,
                              display, choices, const, truemean, FUN)
    match.fun(FUN)(...)
