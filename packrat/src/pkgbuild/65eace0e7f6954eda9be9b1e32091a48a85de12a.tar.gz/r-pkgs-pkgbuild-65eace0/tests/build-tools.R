library(pkgbuild)

check_build_tools(debug = TRUE)
